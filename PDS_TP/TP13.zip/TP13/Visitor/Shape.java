package TP13.Visitor;

public interface Shape {
    void accept(Visitor visitor);
}
