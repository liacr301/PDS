package TP13.Visitor;

public interface Visitor {
    void visit(Circle circle);
    void visit(Rectangle rectangle);
}
