package TP13.Strategy;

public interface Strategy {
    int execute(int a, int b);
}
