package Composite;
public class Sub_Department extends Department{
}
