package Composite;
public interface Employee {
    public void showEmployeeDetails();
}

