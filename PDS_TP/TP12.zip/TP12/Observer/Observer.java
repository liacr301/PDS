package TP12.Observer;

public interface Observer {
    void update(float temperature, float humidity);
}
