package TP12.Mediator;

public interface Mediator {
    void addColleague(ColleagueAbstract colleague);
    void sendMessage();
}
